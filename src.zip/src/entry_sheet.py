async def entry_sheet(message: str):
  return message