from fastapi import FastAPI

from entry_sheet import EntrySheet

app = FastAPI()

@app.post("/ai")
def ai(message: str):
  res = EntrySheet(message)
  return {"message": res}